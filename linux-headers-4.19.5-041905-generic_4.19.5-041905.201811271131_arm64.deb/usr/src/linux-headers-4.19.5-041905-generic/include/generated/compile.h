/* This file is auto generated, version 201811271131 */
/* SMP */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#201811271131 SMP Tue Nov 27 17:10:19 UTC 2018"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gloin"
#define LINUX_COMPILER "gcc version 8.2.0 (Ubuntu 8.2.0-10ubuntu1)"
